@extends('layouts.admin')
@section('header')
    Manage Parents
@endsection
@section('content')
    <div>
        <livewire:admin.manage-parents />
    </div>
@endsection
