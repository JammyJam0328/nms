@extends('layouts.admin')
@section('header')
    Monitoring
@endsection
@section('content')
    <div>
        <livewire:admin.monitoring />
    </div>
@endsection
