@extends('layouts.adviser')
@section('header')
    Manage Students
@endsection
@section('content')
    <div>
        <livewire:adviser.manage-students />
    </div>
@endsection
