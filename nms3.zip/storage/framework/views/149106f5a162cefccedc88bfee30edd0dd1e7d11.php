<div>
    <div>
        <div class="py-2">
            <div>
                <select id="filter"
                    wire:model="filter"
                    name="filter"
                    class="block w-full py-2 pl-3 pr-10 mt-1 text-base border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <option value="1">Reducing Diet</option>
                    <option value="2">Undernourished or Underweight</option>
                </select>
            </div>
        </div>
        <div
            class="grid max-w-3xl grid-cols-1 gap-6 mx-auto mt-8 sm:px-6 lg:max-w-7xl lg:grid-flow-col-dense lg:grid-cols-3">
            <div class="space-y-6 lg:col-start-1 lg:col-span-2">
                <section aria-labelledby="applicant-information-title">
                    <?php $__currentLoopData = $meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div wire:key="meal-list-<?php echo e($key); ?><?php echo e([...$meal][0]->id); ?>">
                            <div class="relative px-3 py-2"
                                x-data="{isopen:false}"
                                x-id="['meals']"
                                @click.away="isopen=false">
                                <div class="flex items-center justify-between p-2 bg-gray-700 rounded-t-lg">
                                    <h1 class="flex items-end space-x-1 font-bold text-white uppercase">
                                        <svg xmlns="http://www.w3.org/2000/svg"
                                            width="24"
                                            height="24"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="2"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            class="feather feather-calendar">
                                            <rect x="3"
                                                y="4"
                                                width="18"
                                                height="18"
                                                rx="2"
                                                ry="2"></rect>
                                            <line x1="16"
                                                y1="2"
                                                x2="16"
                                                y2="6"></line>
                                            <line x1="8"
                                                y1="2"
                                                x2="8"
                                                y2="6"></line>
                                            <line x1="3"
                                                y1="10"
                                                x2="21"
                                                y2="10"></line>
                                        </svg>
                                        <span wire:key="title-<?php echo e([...$meal][0]->id); ?><?php echo e([...$meal][0]->day); ?>"
                                            class="uppercase"><?php echo e([...$meal][0]->day); ?></span>
                                    </h1>
                                    <button @click="isopen=!isopen">
                                        <svg xmlns="http://www.w3.org/2000/svg"
                                            width="24"
                                            height="24"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="2"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            :class="isopen?'rotate-180 duration-500':'duration-500 rotate-0'"
                                            class="text-white feather feather-chevron-down">
                                            <polyline points="6 9 12 15 18 9"></polyline>
                                        </svg>
                                    </button>
                                </div>
                                <div x-cloak
                                    x-show="isopen"
                                    x-collapse.transition.duration.500ms
                                    class="p-2 bg-white rounded-b-lg shadow-md">
                                    <?php $__currentLoopData = $meal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div x-data="{isOpen:false}"
                                            x-on:click.away="isOpen=false"
                                            wire:key="day-<?php echo e($key); ?>">
                                            <div
                                                class="flex justify-between px-2 font-bold text-white uppercase bg-gray-500">
                                                <span><?php echo e($item->meal_time); ?>*</span>
                                                <button x-on:click="isOpen=!isOpen"
                                                    class="font-bold text-white">+</button>
                                            </div>
                                            <div>
                                                <div class="py-1 border-b border-l border-r">
                                                    <?php $__currentLoopData = $item->foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div wire:key="<?php echo e($key); ?>-food"
                                                            class="flex justify-between px-2 bg-white">
                                                            <span> <?php echo e($food->name); ?></span> <button
                                                                wire:click.prevent="removeFood('<?php echo e($food->id); ?>')"
                                                                class="text-red-600">remove</button>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <div x-cloak
                                                    x-show="isOpen"
                                                    x-collapse
                                                    class="flex w-full my-2 space-x-1">
                                                    <input type="text"
                                                        wire:model.defer="new_food"
                                                        name="new_food<?php echo e($item->id); ?>"
                                                        id="new_food<?php echo e($item->id); ?>"
                                                        class="w-full p-2 border border-gray-300">
                                                    <button wire:click.prevent="addFood(<?php echo e($item->id); ?>)"
                                                        type="button"
                                                        class="px-2 py-1 text-white bg-green-600">
                                                        Add
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </section>
                <div class="flex w-full my-3 space-x-2">
                    <input type="text"
                        wire:model.defer="new_day"
                        class="w-full p-2 border"
                        name="day"
                        id="day">
                    <button wire:click.prevent="addDay"
                        class="px-2 py-1 text-white bg-blue-600">
                        Add
                    </button>
                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/livewire/admin/meal-plan.blade.php ENDPATH**/ ?>