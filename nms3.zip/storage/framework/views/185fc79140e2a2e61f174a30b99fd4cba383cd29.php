
<?php $__env->startSection('header'); ?>
    Nutritional Status
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('charts', [])->html();
} elseif ($_instance->childHasBeenRendered('SwSuOXc')) {
    $componentId = $_instance->getRenderedChildComponentId('SwSuOXc');
    $componentTag = $_instance->getRenderedChildComponentTagName('SwSuOXc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SwSuOXc');
} else {
    $response = \Livewire\Livewire::mount('charts', []);
    $html = $response->html();
    $_instance->logRenderedChild('SwSuOXc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/admin-pages/nutritional-status.blade.php ENDPATH**/ ?>