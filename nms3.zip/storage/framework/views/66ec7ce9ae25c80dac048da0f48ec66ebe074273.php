<div>
    <div class="flex flex-col items-center">
        <img src="<?php echo e(asset('images/madandinglogo.jpg')); ?>" class="h-14" alt="">
        <h1 class="text-sm">Department of Education</h1>
        <h1 class="text-sm">Bureau of Learner Support Services</h1>
        <h1 class="text-sm font-semibold">SCHOOL HEALTH DIVISION</h1>
        <h1 class="text-sm font-semibold">NUTRITIONAL STATUS REPORT FOR MADANDING NATIONAL HIGH SCHOOL</h1>
        
    </div>
    <div class="flex mb-5 mt-10 justify-between px-4">
        <h1> <span class="font-bold uppercase">Month of <?php echo e(DateTime::createFromFormat('!m', $allmonth)->format('F')); ?></span></h1>
        <h1><?php echo e($allyear); ?> </h1>
    </div>
    
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="">
            <tr class="border-2 border-gray-300">
                <th width="100" scope="col"
                    class="px-2  text-left text-xs font-bold text-gray-700 uppercase ">GRADE
                    LEVEL</th>
                <th width="100" scope="col"
                    class="px-2  text-left text-xs font-bold text-gray-700 uppercase">
                    ENROLMENT
                </th>
                <th width="500" scope="col"
                    class="px-2  text-left text-xs font-bold text-gray-700 uppercase">
                    <div class="">
                        <div class="border-b flex-1 py-1 text-white bg-gray-700">
                            <h1 class="text-center">BODY MASS INDEX (BMI)</h1>
                        </div>
                        <div class="grid grid-cols-5 text-xs font-semibold text-center">
                            <div>Severely Underweight</div>
                            <div>Underweight</div>
                            <div>Normal</div>
                            <div>Overweight</div>
                            <div>Obese</div>
                        </div>
                    </div>
                </th>
                <th width="500"
                    class="px-2  text-left text-xs font-bold text-gray-700 uppercase">
                    <div class="mb-4">
                        <div class="border-b flex-1 py-1 text-white bg-gray-700">
                            <h1 class="text-center">HEIGHT FOR AGE (HFA)</h1>
                        </div>
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div>Severely Stunted</div>
                            <div>Stunted</div>
                            <div>Normal</div>
                            <div>Tall</div>
                        </div>
                    </div>
                </th>

            </tr>
        </thead>
        <tbody>
            <!-- Odd row -->


            <!-- Even row -->
            <tr class="bg-gray-100 border-b">
                <td class="px-2  whitespace-nowrap text-sm font-medium text-gray-700">Grade
                    7
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="grid grid-cols-1">
                        <div class="flex">
                            <div
                                class=" border-r-2 border-l-2 border-gray-300 flex font-bold text-gray-700 justify-center w-6/12 px-1">
                                M</div>
                            <div
                                class=" w-6/12 border-r-2 border-gray-300 flex justify-center font-bold text-gray-700 px-1">
                                <?php echo e($sevenMale); ?></div>
                        </div>
                        <div class="flex">
                            <div
                                class=" border-r-2 border-l-2 border-gray-300 flex font-bold text-gray-700 justify-center w-6/12 px-1">
                                F</div>
                            <div
                                class=" w-6/12 border-r-2 border-gray-300 flex justify-center font-bold text-gray-700 px-1">
                                <?php echo e($sevenFemale); ?> </div>
                        </div>



                    </div>
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="flex flex-col">
                        <div class="grid grid-cols-5 text-xs font-semibold text-center">
                            <div><?php echo e($sevenSUMale); ?></div>
                            <div><?php echo e($sevenUMale); ?></div>
                            <div><?php echo e($sevenNMale); ?></div>
                            <div><?php echo e($sevenOWMale); ?></div>
                            <div><?php echo e($sevenOMale); ?></div>
                        </div>
                        <div class="grid grid-cols-5 text-xs font-semibold text-center">
                            <div><?php echo e($sevenSUFemale); ?></div>
                            <div><?php echo e($sevenUFemale); ?></div>
                            <div><?php echo e($sevenNFemale); ?></div>
                            <div><?php echo e($sevenOWFemale); ?></div>
                            <div><?php echo e($sevenOFemale); ?></div>
                        </div>
                    </div>
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="flex flex-col">
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div><?php echo e($sevenSSMale); ?></div>
                            <div><?php echo e($sevenSMale); ?></div>
                            <div><?php echo e($sevenNOMale); ?></div>
                            <div><?php echo e($sevenTMale); ?></div>
                        </div>
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div><?php echo e($sevenSSFemale); ?></div>
                            <div><?php echo e($sevenSFemale); ?></div>
                            <div><?php echo e($sevenNOFemale); ?></div>
                            <div><?php echo e($sevenTFemale); ?></div>
                        </div>
                    </div>
                </td>

            </tr>
            <tr class="bg-gray-100 border-b">
                <td class="px-2  whitespace-nowrap text-sm font-medium text-gray-700">Grade
                    8
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="grid grid-cols-1">
                        <div class="flex">
                            <div
                                class=" border-r-2 border-l-2 border-gray-300 flex font-bold text-gray-700 justify-center w-6/12 px-1">
                                M</div>
                            <div
                                class=" w-6/12 border-r-2 border-gray-300 flex justify-center font-bold text-gray-700 px-1"><?php echo e($eightMale); ?></div>
                        </div>
                        <div class="flex">
                            <div
                                class=" border-r-2 border-l-2 border-gray-300 flex font-bold text-gray-700 justify-center w-6/12 px-1">
                                F</div>
                            <div
                                class=" w-6/12 border-r-2 border-gray-300 flex justify-center font-bold text-gray-700 px-1"><?php echo e($eightFemale); ?></div>
                        </div>



                    </div>
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="flex flex-col">



                        <div class="grid grid-cols-5 text-xs font-semibold text-center">

                            <div><?php echo e($eightSUMale); ?></div>
                            <div><?php echo e($eightUMale); ?></div>
                            <div><?php echo e($eightNMale); ?></div>
                            <div><?php echo e($eightOWMale); ?></div>
                            <div><?php echo e($eightOMale); ?></div>
                        </div>
                        <div class="grid grid-cols-5 text-xs font-semibold text-center">
                            <div><?php echo e($eightSUFemale); ?></div>
                            <div><?php echo e($eightUFemale); ?></div>
                            <div><?php echo e($eightNFemale); ?></div>
                            <div><?php echo e($eightOWFemale); ?></div>
                            <div><?php echo e($eightOFemale); ?></div>
                        </div>
                    </div>
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="flex flex-col">
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div><?php echo e($eightSSMale); ?></div>
                            <div><?php echo e($eightSMale); ?></div>
                            <div><?php echo e($eightNOMale); ?></div>
                            <div><?php echo e($eightTMale); ?></div>
                        </div>
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div><?php echo e($eightSSFemale); ?></div>
                            <div><?php echo e($eightSFemale); ?></div>
                            <div><?php echo e($eightNOFemale); ?></div>
                            <div><?php echo e($eightTFemale); ?></div>
                        </div>
                    </div>
                </td>

            </tr>
            <tr class="bg-gray-100 border-b">
                <td class="px-2  whitespace-nowrap text-sm font-medium text-gray-700">Grade
                    9
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="grid grid-cols-1">
                        <div class="flex">
                            <div
                                class=" border-r-2 border-l-2 border-gray-300 flex font-bold text-gray-700 justify-center w-6/12 px-1">
                                M</div>
                            <div
                                class=" w-6/12 border-r-2 border-gray-300 flex justify-center font-bold text-gray-700 px-1"><?php echo e($nineMale); ?>

                            </div>
                        </div>
                        <div class="flex">
                            <div
                                class=" border-r-2 border-l-2 border-gray-300 flex font-bold text-gray-700 justify-center w-6/12 px-1">
                                F</div>
                            <div
                                class=" w-6/12 border-r-2 border-gray-300 flex justify-center font-bold text-gray-700 px-1">
                                <?php echo e($nineFemale); ?></div>
                        </div>



                    </div>
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="flex flex-col">
                        <div class="grid grid-cols-5 text-xs font-semibold text-center">
                            <div><?php echo e($nineSUMale); ?></div>
                            <div><?php echo e($nineUMale); ?></div>
                            <div><?php echo e($nineNMale); ?></div>
                            <div><?php echo e($nineOWMale); ?></div>
                            <div><?php echo e($nineOMale); ?></div>
                        </div>
                        <div class="grid grid-cols-5 text-xs font-semibold text-center">
                            <div><?php echo e($nineSUFemale); ?></div>
                            <div><?php echo e($nineUFemale); ?></div>
                            <div><?php echo e($nineNFemale); ?></div>
                            <div><?php echo e($nineOWFemale); ?></div>
                            <div><?php echo e($nineOFemale); ?></div>
                        </div>
                    </div>
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="flex flex-col">
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div><?php echo e($nineSSMale); ?></div>
                            <div><?php echo e($nineSMale); ?></div>
                            <div><?php echo e($nineNOMale); ?></div>
                            <div><?php echo e($nineTMale); ?></div>
                        </div>
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div><?php echo e($nineSSFemale); ?></div>
                            <div><?php echo e($nineSFemale); ?></div>
                            <div><?php echo e($nineNOFemale); ?></div>
                            <div><?php echo e($nineTFemale); ?></div>
                        </div>
                    </div>
                </td>

            </tr>
            <tr class="bg-gray-100 border-b">
                <td class="px-2  whitespace-nowrap text-sm font-medium text-gray-700">Grade
                    10
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="grid grid-cols-1">
                        <div class="flex">
                            <div
                                class=" border-r-2 border-l-2 border-gray-300 flex font-bold text-gray-700 justify-center w-6/12 px-1">
                                M</div>
                            <div
                                class=" w-6/12 border-r-2 border-gray-300 flex justify-center font-bold text-gray-700 px-1">
                                <?php echo e($tenMale); ?></div>
                        </div>
                        <div class="flex">
                            <div
                                class=" border-r-2 border-l-2 border-gray-300 flex font-bold text-gray-700 justify-center w-6/12 px-1">
                                F</div>
                            <div
                                class=" w-6/12 border-r-2 border-gray-300 flex justify-center font-bold text-gray-700 px-1">
                                <?php echo e($tenFemale); ?></div>
                        </div>



                    </div>
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="flex flex-col">
                        <div class="grid grid-cols-5 text-xs font-semibold text-center">
                            <div><?php echo e($tenSUMale); ?></div>
                            <div><?php echo e($tenUMale); ?></div>
                            <div><?php echo e($tenNMale); ?></div>
                            <div><?php echo e($tenOWMale); ?></div>
                            <div><?php echo e($tenOMale); ?></div>
                        </div>
                        <div class="grid grid-cols-5 text-xs font-semibold text-center">
                            <div><?php echo e($tenSUFemale); ?></div>
                            <div><?php echo e($tenUFemale); ?></div>
                            <div><?php echo e($tenNFemale); ?></div>
                            <div><?php echo e($tenOWFemale); ?></div>
                            <div><?php echo e($tenOFemale); ?></div>
                        </div>
                    </div>
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="flex flex-col">
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div><?php echo e($tenSSMale); ?></div>
                            <div><?php echo e($tenSMale); ?></div>
                            <div><?php echo e($tenNOMale); ?></div>
                            <div><?php echo e($tenTMale); ?></div>
                        </div>
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div><?php echo e($tenSSFemale); ?></div>
                            <div><?php echo e($tenSFemale); ?></div>
                            <div><?php echo e($tenNOFemale); ?></div>
                            <div><?php echo e($tenTFemale); ?></div>
                        </div>
                    </div>
                </td>

            </tr>
            <tr class="bg-gray-100 border-b">
                <td class="px-2  whitespace-nowrap text-sm font-medium text-gray-700">Grade
                    11
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="grid grid-cols-1">
                        <div class="flex">
                            <div
                                class=" border-r-2 border-l-2 border-gray-300 flex font-bold text-gray-700 justify-center w-6/12 px-1">
                                M</div>
                            <div
                                class=" w-6/12 border-r-2 border-gray-300 flex justify-center font-bold text-gray-700 px-1">
                                <?php echo e($elevenMale); ?></div>
                        </div>
                        <div class="flex">
                            <div
                                class=" border-r-2 border-l-2 border-gray-300 flex font-bold text-gray-700 justify-center w-6/12 px-1">
                                F</div>
                            <div
                                class=" w-6/12 border-r-2 border-gray-300 flex justify-center font-bold text-gray-700 px-1">
                                <?php echo e($elevenFemale); ?></div>
                        </div>



                    </div>
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="flex flex-col">
                        <div class="grid grid-cols-5 text-xs font-semibold text-center">
                            <div><?php echo e($elevenSUMale); ?></div>
                            <div><?php echo e($elevenUMale); ?></div>
                            <div><?php echo e($elevenNMale); ?></div>
                            <div><?php echo e($elevenOWMale); ?></div>
                            <div><?php echo e($elevenOMale); ?></div>
                        </div>
                        <div class="grid grid-cols-5 text-xs font-semibold text-center">
                            <div><?php echo e($elevenSUFemale); ?></div>
                            <div><?php echo e($elevenUFemale); ?></div>
                            <div><?php echo e($elevenNFemale); ?></div>
                            <div><?php echo e($elevenOWFemale); ?></div>
                            <div><?php echo e($elevenOFemale); ?></div>
                        </div>
                    </div>
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="flex flex-col">
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div><?php echo e($elevenSSMale); ?></div>
                            <div><?php echo e($elevenSMale); ?></div>
                            <div><?php echo e($elevenNOMale); ?></div>
                            <div><?php echo e($elevenTMale); ?></div>
                        </div>
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div><?php echo e($elevenSSFemale); ?></div>
                            <div><?php echo e($elevenSFemale); ?></div>
                            <div><?php echo e($elevenNOFemale); ?></div>
                            <div><?php echo e($elevenTFemale); ?></div>
                        </div>
                    </div>
                </td>

            </tr>
            <tr class="bg-gray-100 border-b">
                <td class="px-2  whitespace-nowrap text-sm font-medium text-gray-700">Grade
                    12
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="grid grid-cols-1">
                        <div class="flex">
                            <div
                                class=" border-r-2 border-l-2 border-gray-300 flex font-bold text-gray-700 justify-center w-6/12 px-1">
                                M</div>
                            <div
                                class=" w-6/12 border-r-2 border-gray-300 flex justify-center font-bold text-gray-700 px-1">
                                <?php echo e($twelveMale); ?></div>
                        </div>
                        <div class="flex">
                            <div
                                class=" border-r-2 border-l-2 border-gray-300 flex font-bold text-gray-700 justify-center w-6/12 px-1">
                                F</div>
                            <div
                                class=" w-6/12 border-r-2 border-gray-300 flex justify-center font-bold text-gray-700 px-1">
                                <?php echo e($twelveFemale); ?></div>
                        </div>



                    </div>
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="flex flex-col">
                        <div class="grid grid-cols-5 text-xs font-semibold text-center">
                            <div><?php echo e($twelveSUMale); ?></div>
                            <div><?php echo e($twelveUMale); ?></div>
                            <div><?php echo e($twelveNMale); ?></div>
                            <div><?php echo e($twelveOWMale); ?></div>
                            <div><?php echo e($twelveOMale); ?></div>
                        </div>
                        <div class="grid grid-cols-5 text-xs font-semibold text-center">
                            <div><?php echo e($twelveSUFemale); ?></div>
                            <div><?php echo e($twelveUFemale); ?></div>
                            <div><?php echo e($twelveNFemale); ?></div>
                            <div><?php echo e($twelveOWFemale); ?></div>
                            <div><?php echo e($twelveOFemale); ?></div>
                        </div>
                    </div>
                </td>
                <td class="px-2  whitespace-nowrap text-sm text-gray-700">
                    <div class="flex flex-col">
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div><?php echo e($twelveSSMale); ?></div>
                            <div><?php echo e($twelveSMale); ?></div>
                            <div><?php echo e($twelveNOMale); ?></div>
                            <div><?php echo e($twelveTMale); ?></div>
                        </div>
                        <div class="grid grid-cols-4 text-xs font-semibold text-center">
                            <div><?php echo e($twelveSSFemale); ?></div>
                            <div><?php echo e($twelveSFemale); ?></div>
                            <div><?php echo e($twelveNOFemale); ?></div>
                            <div><?php echo e($twelveTFemale); ?></div>
                        </div>
                    </div>
                </td>

            </tr>


            <!-- More people... -->
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/livewire/print-report-all.blade.php ENDPATH**/ ?>