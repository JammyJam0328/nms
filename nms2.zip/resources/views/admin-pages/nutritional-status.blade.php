@extends('layouts.admin')
@section('header')
    Nutritional Status
@endsection
@section('content')
  <livewire:charts />
@endsection
