@extends('layouts.admin')
@section('header')
    Manage Advisers
@endsection
@section('content')
    <div>
        <livewire:admin.accounts />
    </div>
@endsection
