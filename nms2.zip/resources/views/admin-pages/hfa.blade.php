@extends('layouts.admin')
@section('header')
    Height for Age
@endsection
@section('content')
  <livewire:chart-hfa />
@endsection
