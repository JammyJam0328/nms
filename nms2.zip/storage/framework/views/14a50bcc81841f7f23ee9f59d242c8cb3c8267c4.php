


<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>MADNHS</title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    </head>
    <body class="font-sans antialiased bg-mainback">
        <div class="min-h-full flex flex-col justify-center py-12 sm:px-6 lg:px-8">
           
          
            <div class="mt-20 sm:mx-auto sm:w-full sm:max-w-md">
                <div class="bg-green-500 h-3"></div>
                <div class="bg-gray-100 shadow flex justify-center space-x-2 py-3">
                    <img src="<?php echo e(asset('images/school.png')); ?>" class="flex-shrink-0" alt="">
                    <h1 class="text-2xl text-gray-700 font-bold ">MADNHS</h1>
                </div>
                
              <div class="bg-white py-10 px-4   sm:px-10">
                <div class="">
                    <h1 class="text-lg font-bold text-gray-700">Sign In to your Account.</h1>
                </div>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <?php if(session('status')): ?>
            <div class="mb-4 font-medium text-sm text-green-600">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('login')); ?>" class="mt-6">
            <?php echo csrf_field(); ?>

            <div class="relative border border-gray-700  rounded-md px-3 py-2 shadow-sm focus-within:ring-1 focus-within:ring-gray-700 focus-within:border-gray-700">
                <label for="name" class="absolute -top-2 left-2 -mt-px inline-block px-1 bg-white text-sm font-semibold text-gray-800">Email</label>
                <input id="email"  type="email" name="email" :value="old('email')" required autofocus class="block w-full h-8 border-0 p-0 text-gray-900 placeholder-gray-500 focus:ring-0 sm:text-sm" >
              </div>
            <div class="relative border mt-5 border-gray-700     rounded-md px-3 py-2 shadow-sm focus-within:ring-1 focus-within:ring-gray-700 focus-within:border-gray-700">
                <label for="name" class="absolute -top-2 left-2 -mt-px inline-block px-1 bg-white text-sm font-semibold text-gray-800">Password</label>
                <input id="password"  type="password" name="password" required autocomplete="current-password"
                class="block w-full h-8 border-0 p-0 text-gray-900 placeholder-gray-500 focus:ring-0 sm:text-sm" >
              </div>
              <button type="submit" class="mt-8 bg-gray-700 w-full p-2 rounded-md shadow text-white uppercase font-bold mb-10">Sign In</button>

            

            
        </form>
          
               
              </div>
            </div>
          </div>

        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/auth/login.blade.php ENDPATH**/ ?>