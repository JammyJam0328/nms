
<?php $__env->startSection('header'); ?>
    Manage Students
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.manage-students', [])->html();
} elseif ($_instance->childHasBeenRendered('VeTP6Lb')) {
    $componentId = $_instance->getRenderedChildComponentId('VeTP6Lb');
    $componentTag = $_instance->getRenderedChildComponentTagName('VeTP6Lb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VeTP6Lb');
} else {
    $response = \Livewire\Livewire::mount('admin.manage-students', []);
    $html = $response->html();
    $_instance->logRenderedChild('VeTP6Lb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/admin-pages/students.blade.php ENDPATH**/ ?>