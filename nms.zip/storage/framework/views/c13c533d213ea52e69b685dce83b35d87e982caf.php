
<?php $__env->startSection('header'); ?>
     Students BMI
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('student-bmi', [
            'id' => $id,
        ])->html();
} elseif ($_instance->childHasBeenRendered('XktEpg0')) {
    $componentId = $_instance->getRenderedChildComponentId('XktEpg0');
    $componentTag = $_instance->getRenderedChildComponentTagName('XktEpg0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XktEpg0');
} else {
    $response = \Livewire\Livewire::mount('student-bmi', [
            'id' => $id,
        ]);
    $html = $response->html();
    $_instance->logRenderedChild('XktEpg0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adviser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/adviser-pages/student-bmi.blade.php ENDPATH**/ ?>