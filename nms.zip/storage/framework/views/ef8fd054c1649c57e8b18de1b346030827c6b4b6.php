
<?php $__env->startSection('header'); ?>
    Manage Students
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('adviser.manage-students', [])->html();
} elseif ($_instance->childHasBeenRendered('GLPjSbz')) {
    $componentId = $_instance->getRenderedChildComponentId('GLPjSbz');
    $componentTag = $_instance->getRenderedChildComponentTagName('GLPjSbz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GLPjSbz');
} else {
    $response = \Livewire\Livewire::mount('adviser.manage-students', []);
    $html = $response->html();
    $_instance->logRenderedChild('GLPjSbz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adviser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/adviser-pages/my-students.blade.php ENDPATH**/ ?>