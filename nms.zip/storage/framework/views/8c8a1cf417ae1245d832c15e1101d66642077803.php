 <form class="mt-6 ">
     <?php echo csrf_field(); ?>
     <div>
         <div>
             <div>
                 <h3 class="text-lg font-medium leading-6 text-gray-900">Add Parents</h3>
             </div>
             <div class="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                 <div class="sm:col-span-3">
                     <label for="first-name"
                         class="block text-sm font-medium text-gray-700"> First name </label>
                     <div class="mt-1">
                         <input type="text"
                             wire:model.defer="first_name"
                             name="first-name"
                             id="first-name"
                             autocomplete="given-name"
                             class="block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                     </div>
                     <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="text-xs italic text-red-500">
                             <?php echo e($message); ?>

                         </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                 <div class="sm:col-span-3">
                     <label for="middle-name"
                         class="block text-sm font-medium text-gray-700"> Middle name </label>
                     <div class="mt-1">
                         <input type="text"
                             wire:model.defer="middle_name"
                             name="middle-name"
                             id="middle-name"
                             autocomplete="family-name"
                             class="block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                     </div>
                     <?php $__errorArgs = ['middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="text-xs italic text-red-500">
                             <?php echo e($message); ?>

                         </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                 <div class="sm:col-span-3">
                     <label for="last-name"
                         class="block text-sm font-medium text-gray-700"> Last name </label>
                     <div class="mt-1">
                         <input type="text"
                             wire:model.defer="last_name"
                             name="last-name"
                             id="last-name"
                             autocomplete="family-name"
                             class="block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                     </div>
                     <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="text-xs italic text-red-500">
                             <?php echo e($message); ?>

                         </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>

                 <div class="sm:col-span-3">
                     <label for="contact_number"
                         class="block text-sm font-medium text-gray-700"> Contact Number </label>
                     <div class="mt-1">
                         <input id="contact_number"
                             wire:model.defer="contact_number"
                             name="contact_number"
                             type="number"
                             class="block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                     </div>
                     <?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="text-xs italic text-red-500">
                             <?php echo e($message); ?>

                         </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>

                 <div class="sm:col-span-3">
                     <label for="country"
                         class="block text-sm font-medium text-gray-700"> Relationship </label>
                     <div class="mt-1">
                         <select id="country"
                             wire:model.defer="relationship"
                             name="country"
                             autocomplete="country-name"
                             class="block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                             <option value="mother">Mother</option>
                             <option value="father">Father</option>
                             <option value="other">Other</option>
                         </select>
                         <?php $__errorArgs = ['relationship'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <span class="text-xs italic text-red-500">
                                 <?php echo e($message); ?>

                             </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                 </div>

             </div>
         </div>

     </div>

     <div class="pt-5">
         <div class="flex justify-end">
             <button x-on:click="action=''"
                 type="button"
                 class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Cancel</button>
             <button wire:click.prevent="addParent"
                 type="submit"
                 class="inline-flex justify-center px-4 py-2 ml-3 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Save</button>
         </div>
     </div>
 </form>
<?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/admin-pages/components/parents/create.blade.php ENDPATH**/ ?>