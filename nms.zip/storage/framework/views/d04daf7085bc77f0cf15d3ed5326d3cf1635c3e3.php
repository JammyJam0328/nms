
<?php $__env->startSection('header'); ?>
    Manage Parents
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.manage-parents', [])->html();
} elseif ($_instance->childHasBeenRendered('8M0y8Z8')) {
    $componentId = $_instance->getRenderedChildComponentId('8M0y8Z8');
    $componentTag = $_instance->getRenderedChildComponentTagName('8M0y8Z8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8M0y8Z8');
} else {
    $response = \Livewire\Livewire::mount('admin.manage-parents', []);
    $html = $response->html();
    $_instance->logRenderedChild('8M0y8Z8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/admin-pages/parents.blade.php ENDPATH**/ ?>