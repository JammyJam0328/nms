
<?php $__env->startSection('header'); ?>
    Monitor Students
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div>
        
        monitor students
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adviser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/adviser-pages/monitoring.blade.php ENDPATH**/ ?>