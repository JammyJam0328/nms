<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Charts-Print</title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Styles -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <style>
        .wrapper {
            width: 500px;
            height: 500px;
            border: 1px solid black;
            /* for demonstration purposes*/
        }

    </style>
    <?php echo \Livewire\Livewire::styles(); ?>


    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
</head>

<body class="font-sans antialiased">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('chart-print')->html();
} elseif ($_instance->childHasBeenRendered('AFOoRId')) {
    $componentId = $_instance->getRenderedChildComponentId('AFOoRId');
    $componentTag = $_instance->getRenderedChildComponentTagName('AFOoRId');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AFOoRId');
} else {
    $response = \Livewire\Livewire::mount('chart-print');
    $html = $response->html();
    $_instance->logRenderedChild('AFOoRId', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script>
        document.addEventListener('DOMContentLoaded',function(){
            setTimeout(() => {
                window.print();
            }, 2000);
        })
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/admin-pages/nutritional-status-print.blade.php ENDPATH**/ ?>