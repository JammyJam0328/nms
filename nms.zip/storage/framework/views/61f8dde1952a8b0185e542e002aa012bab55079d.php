
<?php $__env->startSection('header'); ?>
    Height for Age
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('chart-hfa', [])->html();
} elseif ($_instance->childHasBeenRendered('CLcl7k9')) {
    $componentId = $_instance->getRenderedChildComponentId('CLcl7k9');
    $componentTag = $_instance->getRenderedChildComponentTagName('CLcl7k9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CLcl7k9');
} else {
    $response = \Livewire\Livewire::mount('chart-hfa', []);
    $html = $response->html();
    $_instance->logRenderedChild('CLcl7k9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/admin-pages/hfa.blade.php ENDPATH**/ ?>