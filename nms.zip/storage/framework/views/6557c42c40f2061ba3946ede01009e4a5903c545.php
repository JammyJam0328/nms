
<?php $__env->startSection('header'); ?>
    Manage Section
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('adviser.manage-students.student-section', ['sectionId' => $id,'section_id' => $id])->html();
} elseif ($_instance->childHasBeenRendered('YY4YYNa')) {
    $componentId = $_instance->getRenderedChildComponentId('YY4YYNa');
    $componentTag = $_instance->getRenderedChildComponentTagName('YY4YYNa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YY4YYNa');
} else {
    $response = \Livewire\Livewire::mount('adviser.manage-students.student-section', ['sectionId' => $id,'section_id' => $id]);
    $html = $response->html();
    $_instance->logRenderedChild('YY4YYNa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adviser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/adviser-pages/my-section.blade.php ENDPATH**/ ?>