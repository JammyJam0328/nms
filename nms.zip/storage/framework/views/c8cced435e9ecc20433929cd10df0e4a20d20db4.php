
<?php $__env->startSection('header'); ?>
        REPORTS
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('report', [])->html();
} elseif ($_instance->childHasBeenRendered('y46O4PO')) {
    $componentId = $_instance->getRenderedChildComponentId('y46O4PO');
    $componentTag = $_instance->getRenderedChildComponentTagName('y46O4PO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('y46O4PO');
} else {
    $response = \Livewire\Livewire::mount('report', []);
    $html = $response->html();
    $_instance->logRenderedChild('y46O4PO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/admin-pages/reports.blade.php ENDPATH**/ ?>