
<?php $__env->startSection('header'); ?>
    Manage Advisers
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.accounts', [])->html();
} elseif ($_instance->childHasBeenRendered('7IB7c8s')) {
    $componentId = $_instance->getRenderedChildComponentId('7IB7c8s');
    $componentTag = $_instance->getRenderedChildComponentTagName('7IB7c8s');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7IB7c8s');
} else {
    $response = \Livewire\Livewire::mount('admin.accounts', []);
    $html = $response->html();
    $_instance->logRenderedChild('7IB7c8s', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/admin-pages/accounts.blade.php ENDPATH**/ ?>