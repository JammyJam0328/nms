<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Report</title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
        <style>
            @media  print{@page  {size: landscape}}
        </style>
        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    </head>
    <body class="font-sans antialiased" onload="window.print()" onafterprint="window.close()">
       <div class="">
        
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('print-report',[
                'month' => $month,
                'year' => $year,
                'section' => $section,
            ])->html();
} elseif ($_instance->childHasBeenRendered('Mkpqz3w')) {
    $componentId = $_instance->getRenderedChildComponentId('Mkpqz3w');
    $componentTag = $_instance->getRenderedChildComponentTagName('Mkpqz3w');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Mkpqz3w');
} else {
    $response = \Livewire\Livewire::mount('print-report',[
                'month' => $month,
                'year' => $year,
                'section' => $section,
            ]);
    $html = $response->html();
    $_instance->logRenderedChild('Mkpqz3w', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
       
        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/admin-pages/report-print.blade.php ENDPATH**/ ?>