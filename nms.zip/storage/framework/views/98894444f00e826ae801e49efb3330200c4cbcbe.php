
<?php $__env->startSection('body'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('student-dashboard', [])->html();
} elseif ($_instance->childHasBeenRendered('qu2ELAT')) {
    $componentId = $_instance->getRenderedChildComponentId('qu2ELAT');
    $componentTag = $_instance->getRenderedChildComponentTagName('qu2ELAT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qu2ELAT');
} else {
    $response = \Livewire\Livewire::mount('student-dashboard', []);
    $html = $response->html();
    $_instance->logRenderedChild('qu2ELAT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SKSU\nms\resources\views/student-pages/dashboard.blade.php ENDPATH**/ ?>