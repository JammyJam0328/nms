<?php

namespace App\Helper;

Class Heightage{

    public static function getMale($year,$months,$height){
       if($year == 12 && $months == 0){
            if ($height <=127.7) {
               return "Severely stunted";
            }
            elseif ($height >= 127.8 && $height <= 134.8) {
                return "Stunted";
            }
            elseif ($height >= 134.9 && $height <= 163.3) {
                return "Normal";
            }
            elseif ($height >= 163.4 ) {
                return "Tall";
            }
        }

        if($year == 12 && $months == 1){
            if ($height <=128.2) {
               return "Severely stunted";
            }
            elseif ($height >= 128.3 && $height <= 135.3) {
                return "Stunted";
            }
            elseif ($height >= 135.4 && $height <= 163.9) {
                return "Normal";
            }
            elseif ($height >= 164.0 ) {
                return "Tall";
            }
        }
        if ($year == 12 && $months == 2) {
            if ($height <=128.6) {
               return "Severely stunted";
            }
            elseif ($height >= 128.7 && $height <= 135.8) {
                return "Stunted";
            }
            elseif ($height >= 135.9 && $height <= 164.5) {
                return "Normal";
            }
            elseif ($height >= 164.6 ) {
                return "Tall";
            }
        }

        if ($year == 12 && $months == 3) {
            if ($height <=129.1) {
               return "Severely stunted";
            }
            elseif ($height >= 129.2 && $height <= 136.3) {
                return "Stunted";
            }
            elseif ($height >= 136.4 && $height <= 165.1) {
                return "Normal";
            }
            elseif ($height >= 165.2 ) {
                return "Tall";
            }
        }

        if ($year == 12 && $months == 4) {
            if ($height <=129.6) {
               return "Severely stunted";
            }
            elseif ($height >= 129.7 && $height <= 136.8) {
                return "Stunted";
            }
            elseif ($height >= 136.9 && $height <= 165.7) {
                return "Normal";
            }
            elseif ($height >= 165.8 ) {
                return "Tall";
            }
        }
        
        if ($year == 12 && $months == 5) {
            if ($height <=130.1) {
               return "Severely stunted";
            }
            elseif ($height >= 130.2 && $height <= 137.3) {
                return "Stunted";
            }
            elseif ($height >= 137.4 && $height <= 166.3) {
                return "Normal";
            }
            elseif ($height >= 166.4 ) {
                return "Tall";
            }
        }

        if ($year == 12 && $months == 6) {
            if ($height <=130.6) {
               return "Severely stunted";
            }
            elseif ($height >= 130.7 && $height <= 137.8) {
                return "Stunted";
            }
            elseif ($height >= 137.9 && $height <= 167.0) {
                return "Normal";
            }
            elseif ($height >= 167.1 ) {
                return "Tall";
            }
        }

        if ($year == 12 && $months == 7) {
            if ($height <=131.1) {
               return "Severely stunted";
            }
            elseif ($height >= 131.2 && $height <= 138.4) {
                return "Stunted";
            }
            elseif ($height >= 138.5 && $height <= 167.6) {
                return "Normal";
            }
            elseif ($height >= 167.7 ) {
                return "Tall";
            }
        }

        if ($year == 12 && $months == 8) {
            if ($height <=131.6) {
               return "Severely stunted";
            }
            elseif ($height >= 131.7 && $height <= 138.9) {
                return "Stunted";
            }
            elseif ($height >= 139.0 && $height <= 168.3) {
                return "Normal";
            }
            elseif ($height >= 168.4 ) {
                return "Tall";
            }
        }

        if ($year == 12 && $months == 9) {
            if ($height <=132.1) {
               return "Severely stunted";
            }
            elseif ($height >= 132.2 && $height <= 139.4) {
                return "Stunted";
            }
            elseif ($height >= 139.5 && $height <= 168.9) {
                return "Normal";
            }
            elseif ($height >= 169.0 ) {
                return "Tall";
            }
        }

        if ($year == 12 && $months == 10) {
            if ($height <=132.6) {
               return "Severely stunted";
            }
            elseif ($height >= 132.7 && $height <= 140.0) {
                return "Stunted";
            }
            elseif ($height >= 140.1 && $height <= 169.6) {
                return "Normal";
            }
            elseif ($height >= 169.7 ) {
                return "Tall";
            }
        }

        if ($year == 12 && $months == 11) {
            if ($height <=133.1) {
               return "Severely stunted";
            }
            elseif ($height >= 133.2 && $height <= 140.5) {
                return "Stunted";
            }
            elseif ($height >= 140.6 && $height <= 170.2) {
                return "Normal";
            }
            elseif ($height >= 170.3 ) {
                return "Tall";
            }
        }
        
        if ($year == 13 && $months == 0) {
            if ($height <=133.7) {
               return "Severely stunted";
            }
            elseif ($height >= 133.8 && $height <= 141.1) {
                return "Stunted";
            }
            elseif ($height >= 141.2 && $height <= 170.9) {
                return "Normal";
            }
            elseif ($height >= 171.0 ) {
                return "Tall";
            }
        }

        if ($year == 13 && $months == 1) {
            if ($height <=134.2) {
               return "Severely stunted";
            }
            elseif ($height >= 134.3 && $height <= 141.6) {
                return "Stunted";
            }
            elseif ($height >= 141.7 && $height <= 171.6) {
                return "Normal";
            }
            elseif ($height >= 171.7 ) {
                return "Tall";
            }
        }

        if ($year == 13 && $months == 2) {
            if ($height <=134.7) {
               return "Severely stunted";
            }
            elseif ($height >= 134.8 && $height <= 142.2) {
                return "Stunted";
            }
            elseif ($height >= 142.3 && $height <= 172.2) {
                return "Normal";
            }
            elseif ($height >= 172.3 ) {
                return "Tall";
            }
        }

        if ($year == 13 && $months == 3) {
            if ($height <=135.3) {
               return "Severely stunted";
            }
            elseif ($height >= 135.4 && $height <= 142.8) {
                return "Stunted";
            }
            elseif ($height >= 142.9 && $height <= 172.9) {
                return "Normal";
            }
            elseif ($height >= 173.0 ) {
                return "Tall";
            }
        }

        if ($year == 13 && $months == 4) {
            if ($height <=135.8) {
               return "Severely stunted";
            }
            elseif ($height >= 135.9 && $height <= 143.3) {
                return "Stunted";
            }
            elseif ($height >= 143.4 && $height <= 173.5) {
                return "Normal";
            }
            elseif ($height >= 173.6 ) {
                return "Tall";
            }
        }

        if ($year == 13 && $months == 5) {
            if ($height <=136.3) {
               return "Severely stunted";
            }
            elseif ($height >= 136.4 && $height <= 143.9) {
                return "Stunted";
            }
            elseif ($height >= 144.0 && $height <= 174.2) {
                return "Normal";
            }
            elseif ($height >= 174.3 ) {
                return "Tall";
            }
        }

        if ($year == 13 && $months == 6) {
            if ($height <=136.9) {
               return "Severely stunted";
            }
            elseif ($height >= 137.0 && $height <= 144.4) {
                return "Stunted";
            }
            elseif ($height >= 144.5 && $height <= 174.8) {
                return "Normal";
            }
            elseif ($height >= 174.9 ) {
                return "Tall";
            }
        }

        if ($year == 13 && $months == 7) {
            if ($height <=136.4) {
               return "Severely stunted";
            }
            elseif ($height >= 136.5 && $height <= 145.0) {
                return "Stunted";
            }
            elseif ($height >= 145.1 && $height <= 175.5) {
                return "Normal";
            }
            elseif ($height >= 175.6 ) {
                return "Tall";
            }
        }

        if ($year == 13 && $months == 8) {
            if ($height <=137.9) {
               return "Severely stunted";
            }
            elseif ($height >= 138.0 && $height <= 145.6) {
                return "Stunted";
            }
            elseif ($height >= 145.7 && $height <= 176.1) {
                return "Normal";
            }
            elseif ($height >= 176.2 ) {
                return "Tall";
            }
        }

        if ($year == 13 && $months == 9) {
            if ($height <=138.5) {
               return "Severely stunted";
            }
            elseif ($height >= 138.6 && $height <= 146.1) {
                return "Stunted";
            }
            elseif ($height >= 146.2 && $height <= 176.7) {
                return "Normal";
            }
            elseif ($height >= 176.8 ) {
                return "Tall";
            }
        }

        if ($year == 13 && $months == 10) {
            if ($height <=139.0) {
               return "Severely stunted";
            }
            elseif ($height >= 139.1 && $height <= 146.6) {
                return "Stunted";
            }
            elseif ($height >= 146.7 && $height <= 177.4) {
                return "Normal";
            }
            elseif ($height >= 177.5 ) {
                return "Tall";
            }
        }

        if ($year == 13 && $months == 11) {
            if ($height <=139.5) {
               return "Severely stunted";
            }
            elseif ($height >= 139.6 && $height <= 147.2) {
                return "Stunted";
            }
            elseif ($height >= 147.3 && $height <= 178.0) {
                return "Normal";
            }
            elseif ($height >= 178.1 ) {
                return "Tall";
            }
        }

        if ($year == 14 && $months == 0) {
            if ($height <=140.0) {
               return "Severely stunted";
            }
            elseif ($height >= 140.1 && $height <= 147.7) {
                return "Stunted";
            }
            elseif ($height >= 147.8 && $height <= 178.6) {
                return "Normal";
            }
            elseif ($height >= 178.7 ) {
                return "Tall";
            }
        }

        if ($year == 14 && $months == 1) {
            if ($height <=140.5) {
               return "Severely stunted";
            }
            elseif ($height >= 140.6 && $height <= 148.2) {
                return "Stunted";
            }
            elseif ($height >= 148.3 && $height <= 179.1) {
                return "Normal";
            }
            elseif ($height >= 179.2 ) {
                return "Tall";
            }
        }

        if ($year == 14 && $months == 2) {
            if ($height <=141.0) {
               return "Severely stunted";
            }
            elseif ($height >= 141.1 && $height <= 147.7) {
                return "Stunted";
            }
            elseif ($height >= 148.8 && $height <= 179.7) {
                return "Normal";
            }
            elseif ($height >= 179.8 ) {
                return "Tall";
            }
        }

        if ($year == 14 && $months == 3) {
            if ($height <=141.5) {
               return "Severely stunted";
            }
            elseif ($height >= 141.6 && $height <= 149.2) {
                return "Stunted";
            }
            elseif ($height >= 149.3 && $height <= 180.3) {
                return "Normal";
            }
            elseif ($height >= 180.4 ) {
                return "Tall";
            }
        }

        if ($year == 14 && $months == 4) {
            if ($height <=142.0) {
               return "Severely stunted";
            }
            elseif ($height >= 142.1 && $height <= 149.7) {
                return "Stunted";
            }
            elseif ($height >= 149.8 && $height <= 180.8) {
                return "Normal";
            }
            elseif ($height >= 180.9 ) {
                return "Tall";
            }
        }

        if ($year == 14 && $months == 5) {
            if ($height <=142.4) {
               return "Severely stunted";
            }
            elseif ($height >= 142.5 && $height <= 150.2) {
                return "Stunted";
            }
            elseif ($height >= 150.3 && $height <= 181.3) {
                return "Normal";
            }
            elseif ($height >= 181.4 ) {
                return "Tall";
            }
        }

        if ($year == 14 && $months == 6) {
            if ($height <=142.9) {
               return "Severely stunted";
            }
            elseif ($height >= 143.0 && $height <= 150.7) {
                return "Stunted";
            }
            elseif ($height >= 150.8 && $height <= 181.8) {
                return "Normal";
            }
            elseif ($height >= 181.9 ) {
                return "Tall";
            }
        }

        if ($year == 14 && $months == 7) {
            if ($height <=143.3) {
               return "Severely stunted";
            }
            elseif ($height >= 143.4 && $height <= 151.1) {
                return "Stunted";
            }
            elseif ($height >= 151.2 && $height <= 182.3) {
                return "Normal";
            }
            elseif ($height >= 182.4 ) {
                return "Tall";
            }
        }

        if ($year == 14 && $months == 8) {
            if ($height <=143.8) {
               return "Severely stunted";
            }
            elseif ($height >= 143.9 && $height <= 151.6) {
                return "Stunted";
            }
            elseif ($height >= 151.7 && $height <= 182.8) {
                return "Normal";
            }
            elseif ($height >= 182.9 ) {
                return "Tall";
            }
        }

        if ($year == 14 && $months == 9) {
            if ($height <=144.2) {
               return "Severely stunted";
            }
            elseif ($height >= 144.3 && $height <= 152.0) {
                return "Stunted";
            }
            elseif ($height >= 152.1 && $height <= 183.3) {
                return "Normal";
            }
            elseif ($height >= 183.4 ) {
                return "Tall";
            }
        }

        if ($year == 14 && $months == 10) {
            if ($height <=144.6) {
               return "Severely stunted";
            }
            elseif ($height >= 144.7 && $height <= 152.4) {
                return "Stunted";
            }
            elseif ($height >= 152.5 && $height <= 183.7) {
                return "Normal";
            }
            elseif ($height >= 183.8 ) {
                return "Tall";
            }
        }

        if ($year == 14 && $months == 11) {
            if ($height <=145.0) {
               return "Severely stunted";
            }
            elseif ($height >= 145.1 && $height <= 152.8) {
                return "Stunted";
            }
            elseif ($height >= 152.9 && $height <= 184.1) {
                return "Normal";
            }
            elseif ($height >= 184.2 ) {
                return "Tall";
            }
        }


        if ($year == 15 && $months == 0) {
            if ($height <=145.4) {
               return "Severely stunted";
            }
            elseif ($height >= 145.5 && $height <= 153.3) {
                return "Stunted";
            }
            elseif ($height >= 153.4 && $height <= 184.6) {
                return "Normal";
            }
            elseif ($height >= 184.7 ) {
                return "Tall";
            }
        }

        if ($year == 15 && $months == 1) {
            if ($height <=145.98) {
               return "Severely stunted";
            }
            elseif ($height >= 145.9 && $height <= 153.6) {
                return "Stunted";
            }
            elseif ($height >= 153.7 && $height <= 185.0) {
                return "Normal";
            }
            elseif ($height >= 185.1 ) {
                return "Tall";
            }
        }

        if ($year == 15 && $months == 2) {
            if ($height <=146.2) {
               return "Severely stunted";
            }
            elseif ($height >= 146.3 && $height <= 154.0) {
                return "Stunted";
            }
            elseif ($height >= 154.1 && $height <= 185.4) {
                return "Normal";
            }
            elseif ($height >= 185.5 ) {
                return "Tall";
            }
        }

        if ($year == 15 && $months == 3) {
            if ($height <=146.6) {
               return "Severely stunted";
            }
            elseif ($height >= 146.7 && $height <= 154.4) {
                return "Stunted";
            }
            elseif ($height >= 154.5 && $height <= 185.7) {
                return "Normal";
            }
            elseif ($height >= 185.8 ) {
                return "Tall";
            }
        }

        if ($year == 15 && $months == 4) {
            if ($height <=147.0) {
               return "Severely stunted";
            }
            elseif ($height >= 147.1 && $height <= 154.8) {
                return "Stunted";
            }
            elseif ($height >= 154.9 && $height <= 186.1) {
                return "Normal";
            }
            elseif ($height >= 186.2 ) {
                return "Tall";
            }
        }

        if ($year == 15 && $months == 5) {
            if ($height <=147.3) {
               return "Severely stunted";
            }
            elseif ($height >= 147.4 && $height <= 155.1) {
                return "Stunted";
            }
            elseif ($height >= 155.2 && $height <= 186.4) {
                return "Normal";
            }
            elseif ($height >= 186.5 ) {
                return "Tall";
            }
        }

        if ($year == 15 && $months == 6) {
            if ($height <=147.6) {
               return "Severely stunted";
            }
            elseif ($height >= 147.7 && $height <= 155.4) {
                return "Stunted";
            }
            elseif ($height >= 155.5 && $height <= 186.8) {
                return "Normal";
            }
            elseif ($height >= 186.9 ) {
                return "Tall";
            }
        }

        if ($year == 15 && $months == 7) {
            if ($height <=148.0) {
               return "Severely stunted";
            }
            elseif ($height >= 148.1 && $height <= 155.8) {
                return "Stunted";
            }
            elseif ($height >= 155.9 && $height <= 187.1) {
                return "Normal";
            }
            elseif ($height >= 187.2 ) {
                return "Tall";
            }
        }

        if ($year == 15 && $months == 8) {
            if ($height <=148.3) {
               return "Severely stunted";
            }
            elseif ($height >= 148.4 && $height <= 156.1) {
                return "Stunted";
            }
            elseif ($height >= 156.2 && $height <= 187.4) {
                return "Normal";
            }
            elseif ($height >= 187.5 ) {
                return "Tall";
            }
        }

        if ($year == 15 && $months == 9) {
            if ($height <=148.6) {
               return "Severely stunted";
            }
            elseif ($height >= 148.7 && $height <= 156.4) {
                return "Stunted";
            }
            elseif ($height >= 156.5 && $height <= 187.7) {
                return "Normal";
            }
            elseif ($height >= 187.8 ) {
                return "Tall";
            }
        }

        if ($year == 15 && $months == 10) {
            if ($height <=148.9) {
               return "Severely stunted";
            }
            elseif ($height >= 149.9 && $height <= 156.7) {
                return "Stunted";
            }
            elseif ($height >= 156.8 && $height <= 187.9) {
                return "Normal";
            }
            elseif ($height >= 188.0 ) {
                return "Tall";
            }
        }

        if ($year == 15 && $months == 11) {
            if ($height <=149.2) {
               return "Severely stunted";
            }
            elseif ($height >= 149.3 && $height <= 157.0) {
                return "Stunted";
            }
            elseif ($height >= 157.1 && $height <= 188.2) {
                return "Normal";
            }
            elseif ($height >= 188.3 ) {
                return "Tall";
            }
        }

        if ($year == 16 && $months == 0) {
            if ($height <=149.5) {
               return "Severely stunted";
            }
            elseif ($height >= 149.6 && $height <= 157.3) {
                return "Stunted";
            }
            elseif ($height >= 157.4 && $height <= 188.4) {
                return "Normal";
            }
            elseif ($height >= 188.5 ) {
                return "Tall";
            }
        }

        if ($year == 16 && $months == 1) {
            if ($height <=149.8) {
               return "Severely stunted";
            }
            elseif ($height >= 149.9 && $height <= 157.5) {
                return "Stunted";
            }
            elseif ($height >= 157.6 && $height <= 188.7) {
                return "Normal";
            }
            elseif ($height >= 188.8 ) {
                return "Tall";
            }
        }

        if ($year == 16 && $months == 2) {
            if ($height <=150.0) {
               return "Severely stunted";
            }
            elseif ($height >= 150.1 && $height <= 157.8) {
                return "Stunted";
            }
            elseif ($height >= 157.9 && $height <= 188.9) {
                return "Normal";
            }
            elseif ($height >= 189.0 ) {
                return "Tall";
            }
        }

        if ($year == 16 && $months == 3) {
            if ($height <=150.3) {
               return "Severely stunted";
            }
            elseif ($height >= 150.4 && $height <= 158.0) {
                return "Stunted";
            }
            elseif ($height >= 158.1 && $height <= 189.1) {
                return "Normal";
            }
            elseif ($height >= 189.2 ) {
                return "Tall";
            }
        }

        if ($year == 16 && $months == 4) {
            if ($height <=150.5) {
               return "Severely stunted";
            }
            elseif ($height >= 150.6 && $height <= 158.3) {
                return "Stunted";
            }
            elseif ($height >= 158.4 && $height <= 189.3) {
                return "Normal";
            }
            elseif ($height >= 189.4 ) {
                return "Tall";
            }
        }

        if ($year == 16 && $months == 5) {
            if ($height <=150.8) {
               return "Severely stunted";
            }
            elseif ($height >= 150.9 && $height <= 158.5) {
                return "Stunted";
            }
            elseif ($height >= 158.6 && $height <= 189.5) {
                return "Normal";
            }
            elseif ($height >= 189.6 ) {
                return "Tall";
            }
        }

        if ($year == 16 && $months == 6) {
            if ($height <=151.0) {
               return "Severely stunted";
            }
            elseif ($height >= 151.1 && $height <= 158.7) {
                return "Stunted";
            }
            elseif ($height >= 158.8 && $height <= 189.7) {
                return "Normal";
            }
            elseif ($height >= 189.8 ) {
                return "Tall";
            }
        }

        if ($year == 16 && $months == 7) {
            if ($height <=151.2) {
               return "Severely stunted";
            }
            elseif ($height >= 151.3 && $height <= 158.9) {
                return "Stunted";
            }
            elseif ($height >= 159.0 && $height <= 189.8) {
                return "Normal";
            }
            elseif ($height >= 189.9 ) {
                return "Tall";
            }
        }

        if ($year == 16 && $months == 8) {
            if ($height <=151.4) {
               return "Severely stunted";
            }
            elseif ($height >= 151.5 && $height <= 159.1) {
                return "Stunted";
            }
            elseif ($height >= 159.2 && $height <= 190.0) {
                return "Normal";
            }
            elseif ($height >= 190.1 ) {
                return "Tall";
            }
        }

        if ($year == 16 && $months == 9) {
            if ($height <=151.6) {
               return "Severely stunted";
            }
            elseif ($height >= 151.7 && $height <= 159.3) {
                return "Stunted";
            }
            elseif ($height >= 159.4 && $height <= 190.1) {
                return "Normal";
            }
            elseif ($height >= 190.2 ) {
                return "Tall";
            }
        }

        if ($year == 16 && $months == 10) {
            if ($height <=151.8) {
               return "Severely stunted";
            }
            elseif ($height >= 151.9 && $height <= 159.5) {
                return "Stunted";
            }
            elseif ($height >= 159.6 && $height <= 190.2) {
                return "Normal";
            }
            elseif ($height >= 190.3 ) {
                return "Tall";
            }
        }

        if ($year == 16 && $months == 11) {
            if ($height <=152.0) {
               return "Severely stunted";
            }
            elseif ($height >= 152.1 && $height <= 159.6) {
                return "Stunted";
            }
            elseif ($height >= 159.7 && $height <= 190.3) {
                return "Normal";
            }
            elseif ($height >= 190.4 ) {
                return "Tall";
            }
        }

        if ($year == 17 && $months == 0) {
            if ($height <=152.1) {
               return "Severely stunted";
            }
            elseif ($height >= 152.2 && $height <= 159.8) {
                return "Stunted";
            }
            elseif ($height >= 159.9 && $height <= 190.4) {
                return "Normal";
            }
            elseif ($height >= 190.5 ) {
                return "Tall";
            }
        }

        if ($year == 17 && $months == 1) {
            if ($height <=152.3) {
               return "Severely stunted";
            }
            elseif ($height >= 152.4 && $height <= 159.9) {
                return "Stunted";
            }
            elseif ($height >= 160.0 && $height <= 190.5) {
                return "Normal";
            }
            elseif ($height >= 190.6 ) {
                return "Tall";
            }
        }

        if ($year == 17 && $months == 2) {
            if ($height <=152.4) {
               return "Severely stunted";
            }
            elseif ($height >= 152.5 && $height <= 160.1) {
                return "Stunted";
            }
            elseif ($height >= 160.2 && $height <= 190.6) {
                return "Normal";
            }
            elseif ($height >= 190.7 ) {
                return "Tall";
            }
        }

        if ($year == 17 && $months == 3) {
            if ($height <=152.6) {
               return "Severely stunted";
            }
            elseif ($height >= 152.7 && $height <= 160.2) {
                return "Stunted";
            }
            elseif ($height >= 160.3 && $height <= 190.7) {
                return "Normal";
            }
            elseif ($height >= 190.8 ) {
                return "Tall";
            }
        }

        if ($year == 17 && $months == 4) {
            if ($height <=152.7) {
               return "Severely stunted";
            }
            elseif ($height >= 152.8 && $height <= 160.3) {
                return "Stunted";
            }
            elseif ($height >= 160.4 && $height <= 190.8) {
                return "Normal";
            }
            elseif ($height >= 190.9 ) {
                return "Tall";
            }
        }

        if ($year == 17 && $months == 5) {
            if ($height <=152.9) {
               return "Severely stunted";
            }
            elseif ($height >= 153.0 && $height <= 160.4) {
                return "Stunted";
            }
            elseif ($height >= 160.5 && $height <= 190.8) {
                return "Normal";
            }
            elseif ($height >= 190.9 ) {
                return "Tall";
            }
        }

        if ($year == 17 && $months == 6) {
            if ($height <=153.0) {
               return "Severely stunted";
            }
            elseif ($height >= 153.1 && $height <= 160.5) {
                return "Stunted";
            }
            elseif ($height >= 160.6 && $height <= 190.9) {
                return "Normal";
            }
            elseif ($height >= 191.0 ) {
                return "Tall";
            }
        }

        if ($year == 17 && $months == 7) {
            if ($height <=153.1) {
               return "Severely stunted";
            }
            elseif ($height >= 153.2 && $height <= 160.7) {
                return "Stunted";
            }
            elseif ($height >= 160.8 && $height <= 190.9) {
                return "Normal";
            }
            elseif ($height >= 191.0 ) {
                return "Tall";
            }
        }

        if ($year == 17 && $months == 8) {
            if ($height <=153.2) {
               return "Severely stunted";
            }
            elseif ($height >= 153.3 && $height <= 160.8) {
                return "Stunted";
            }
            elseif ($height >= 160.9 && $height <= 191.0) {
                return "Normal";
            }
            elseif ($height >= 191.1 ) {
                return "Tall";
            }
        }

        if ($year == 17 && $months == 9) {
            if ($height <=153.3) {
               return "Severely stunted";
            }
            elseif ($height >= 153.4 && $height <= 160.8) {
                return "Stunted";
            }
            elseif ($height >= 161.9 && $height <= 191.0) {
                return "Normal";
            }
            elseif ($height >= 191.1 ) {
                return "Tall";
            }
        }

        if ($year == 17 && $months == 10) {
            if ($height <=153.4) {
               return "Severely stunted";
            }
            elseif ($height >= 153.5 && $height <= 160.9) {
                return "Stunted";
            }
            elseif ($height >= 161.0 && $height <= 191.0) {
                return "Normal";
            }
            elseif ($height >= 191.1 ) {
                return "Tall";
            }
        }

        if ($year == 17 && $months == 11) {
            if ($height <=153.5) {
               return "Severely stunted";
            }
            elseif ($height >= 153.6 && $height <= 161.0) {
                return "Stunted";
            }
            elseif ($height >= 161.1 && $height <= 191.1) {
                return "Normal";
            }
            elseif ($height >= 191.2 ) {
                return "Tall";
            }
        }

        if ($year == 18 && $months == 0) {
            if ($height <=153.6) {
               return "Severely stunted";
            }
            elseif ($height >= 153.7 && $height <= 161.1) {
                return "Stunted";
            }
            elseif ($height >= 161.2 && $height <= 191.1) {
                return "Normal";
            }
            elseif ($height >= 191.2 ) {
                return "Tall";
            }
        }

        if ($year == 18 && $months == 1) {
            if ($height <=153.7) {
               return "Severely stunted";
            }
            elseif ($height >= 153.8 && $height <= 161.2) {
                return "Stunted";
            }
            elseif ($height >= 161.3 && $height <= 191.1) {
                return "Normal";
            }
            elseif ($height >= 191.2 ) {
                return "Tall";
            }
        }

        if ($year == 18 && $months == 2) {
            if ($height <=153.8) {
               return "Severely stunted";
            }
            elseif ($height >= 153.9 && $height <= 161.3) {
                return "Stunted";
            }
            elseif ($height >= 161.4 && $height <= 191.1) {
                return "Normal";
            }
            elseif ($height >= 191.2 ) {
                return "Tall";
            }
        }

        if ($year == 18 && $months == 3) {
            if ($height <=153.9) {
               return "Severely stunted";
            }
            elseif ($height >= 154.0 && $height <= 161.3) {
                return "Stunted";
            }
            elseif ($height >= 161.4 && $height <= 191.1) {
                return "Normal";
            }
            elseif ($height >= 191.2 ) {
                return "Tall";
            }
        }

        if ($year == 18 && $months == 4) {
            if ($height <=154.0) {
               return "Severely stunted";
            }
            elseif ($height >= 154.1 && $height <= 161.4) {
                return "Stunted";
            }
            elseif ($height >= 161.5 && $height <= 191.1) {
                return "Normal";
            }
            elseif ($height >= 191.2 ) {
                return "Tall";
            }
        }

        if ($year == 18 && $months == 5) {
            if ($height <=154.1) {
               return "Severely stunted";
            }
            elseif ($height >= 154.2 && $height <= 161.5) {
                return "Stunted";
            }
            elseif ($height >= 161.6 && $height <= 191.1) {
                return "Normal";
            }
            elseif ($height >= 191.2 ) {
                return "Tall";
            }
        }

        if ($year == 18 && $months == 6) {
            if ($height <=154.1) {
               return "Severely stunted";
            }
            elseif ($height >= 154.2 && $height <= 161.5) {
                return "Stunted";
            }
            elseif ($height >= 161.6 && $height <= 191.1) {
                return "Normal";
            }
            elseif ($height >= 191.2 ) {
                return "Tall";
            }
        }

        if ($year == 18 && $months == 7) {
            if ($height <=154.2) {
               return "Severely stunted";
            }
            elseif ($height >= 154.3 && $height <= 161.6) {
                return "Stunted";
            }
            elseif ($height >= 161.7 && $height <= 191.2) {
                return "Normal";
            }
            elseif ($height >= 191.3 ) {
                return "Tall";
            }
        }

        if ($year == 18 && $months == 8) {
            if ($height <=154.3) {
               return "Severely stunted";
            }
            elseif ($height >= 154.4 && $height <= 161.6) {
                return "Stunted";
            }
            elseif ($height >= 161.7 && $height <= 191.2) {
                return "Normal";
            }
            elseif ($height >= 191.3 ) {
                return "Tall";
            }
        }

        if ($year == 18 && $months == 9) {
            if ($height <=154.4) {
               return "Severely stunted";
            }
            elseif ($height >= 154.5 && $height <= 161.7) {
                return "Stunted";
            }
            elseif ($height >= 161.8 && $height <= 191.2) {
                return "Normal";
            }
            elseif ($height >= 191.3 ) {
                return "Tall";
            }
        }

        if ($year == 18 && $months == 10) {
            if ($height <=154.4) {
               return "Severely stunted";
            }
            elseif ($height >= 154.5 && $height <= 161.7) {
                return "Stunted";
            }
            elseif ($height >= 161.8 && $height <= 191.1) {
                return "Normal";
            }
            elseif ($height >= 191.2 ) {
                return "Tall";
            }
        }

        if ($year == 18 && $months == 11) {
            if ($height <=154.5) {
               return "Severely stunted";
            }
            elseif ($height >= 154.6 && $height <= 161.8) {
                return "Stunted";
            }
            elseif ($height >= 161.9 && $height <= 191.1) {
                return "Normal";
            }
            elseif ($height >= 191.2 ) {
                return "Tall";
            }
        }
        
        if ($year >= 19) {
            if ($height <=154.5) {
               return "Severely stunted";
            }
            elseif ($height >= 154.6 && $height <= 161.8) {
                return "Stunted";
            }
            elseif ($height >= 161.9 && $height <= 191.1) {
                return "Normal";
            }
            elseif ($height >= 191.2 ) {
                return "Tall";
            }
        }
    }

    
    public static function getFemale($year,$months,$height){    
            if($year==12 && $months==0){
                if($height<=130.6){
                    return "Severely stunted";
                }
                elseif($height>=130.7 && $height<=137.5){
                    return "Stunted";
                }
                elseif($height>=137.6 && $height<=164.9){
                    return "Normal";
                }
                elseif($height>=165.0){
                    return "Tall";
                }
               
            }
            if($year==12 && $months==1){
                if($height<=131.1){
                    return "Severely stunted";
                }
                elseif($height>=131.2 && $height<=137.9){
                    return "Stunted";
                }
                elseif($height>=138.0 && $height<=165.4){
                    return "Normal";
                }
                elseif($height>=165.5){
                    return "Tall";
                }
            }

            if($year==12 && $months==2){
                if($height<=131.5){
                    return "Severely stunted";
                }
                elseif($height>=131.6 && $height<=138.4){
                    return "Stunted";
                }
                elseif($height>=138.5 && $height<=165.9){
                    return "Normal";
                }
                elseif($height>=166.0){
                    return "Tall";
                }
              
            }

            if($year==12 && $months==3){
                if($height<=131.9){
                    return "Severely stunted";
                }
                elseif($height>=132.0 && $height<=138.8){
                    return "Stunted";
                }
                elseif($height>=138.9 && $height<=166.4){
                    return "Normal";
                }
                elseif($height>=166.5){
                    return "Tall";
                }
            }

            if($year==12 && $months==4){
                if($height<=132.4){
                    return "Severely stunted";
                }
                elseif($height>=132.5 && $height<=139.2){
                    return "Stunted";
                }
                elseif($height>=139.3 && $height<=166.9){
                    return "Normal";
                }
                elseif($height>=167.0){
                    return "Tall";
                }
            }

            if($year==12 && $months==5){
                if($height<=132.8){
                    return "Severely stunted";
                }
                elseif($height>=132.9 && $height<=139.7){
                    return "Stunted";
                }
                elseif($height>=139.8 && $height<=167.4){
                    return "Normal";
                }
                elseif($height>=167.5){
                    return "Tall";
                }
            }

            if($year==12 && $months==6){
                if($height<=133.2){
                    return "Severely stunted";
                }
                elseif($height>=133.3 && $height<=140.1){
                    return "Stunted";
                }
                elseif($height>=140.2 && $height<=167.8){
                    return "Normal";
                }
                elseif($height>=167.9){
                    return "Tall";
                }
            }
            //12
            if($year==12 && $months==7){
                if($height<=133.6){
                    return "Severely stunted";
                }
                elseif($height>=133.7 && $height<=140.5){
                    return "Stunted";
                }
                elseif($height>=140.6 && $height<=168.3){
                    return "Normal";
                }
                elseif($height>=168.4){
                    return "Tall";
                }
            }

            if($year==12 && $months==8){
                if($height<=134.0){
                    return "Severely stunted";
                }
                elseif($height>=134.1 && $height<=140.9){
                    return "Stunted";
                }
                elseif($height>=141.0 && $height<=168.7){
                    return "Normal";
                }
                elseif($height>=168.8){
                    return "Tall";
                }
            }

            if($year==12 && $months==9){
                if($height<=134.4){
                    return "Severely stunted";
                }
                elseif($height>=134.5 && $height<=141.3){
                    return "Stunted";
                }
                elseif($height>=141.4 && $height<=169.1){
                    return "Normal";
                }
                elseif($height>=169.2){
                    return "Tall";
                }
            }

            if($year==12 && $months==10){
                if($height<=134.7){
                    return "Severely stunted";
                }
                elseif($height>=134.8 && $height<=142.7){
                    return "Stunted";
                }
                elseif($height>=141.2 && $height<=169.5){
                    return "Normal";
                }
                elseif($height>=169.6){
                    return "Tall";
                }
            }

            if($year==12 && $months==11){
                if($height<=135.1){
                    return "Severely stunted";
                }
                elseif($height>=135.2 && $height<=142.0){
                    return "Stunted";
                }
                elseif($height>=142.1 && $height<=169.9){
                    return "Normal";
                }
                elseif($height>=170.0){
                    return "Tall";
                }
            }

            if($year==13 && $months==0){
                if($height<=135.5){
                    return "Severely stunted";
                }
                elseif($height>=135.6 && $height<=142.4){
                    return "Stunted";
                }
                elseif($height>=142.5 && $height<=170.3){
                    return "Normal";
                }
                elseif($height>=170.4){
                    return "Tall";
                }
            }

            if($year==13 && $months==1){
                if($height<=135.8){
                    return "Severely stunted";
                }
                elseif($height>=135.9 && $height<=142.7){
                    return "Stunted";
                }
                elseif($height>=142.8 && $height<=170.6){
                    return "Normal";
                }
                elseif($height>=170.7){
                    return "Tall";
                }
            }

            if($year==13 && $months==2){
                if($height<=136.1){
                    return "Severely stunted";
                }
                elseif($height>=136.2 && $height<=143.1){
                    return "Stunted";
                }
                elseif($height>=143.2 && $height<=171.0){
                    return "Normal";
                }
                elseif($height>=171.1){
                    return "Tall";
                }
            }

            if($year==13 && $months==3){
                if($height<=136.4){
                    return "Severely stunted";
                }
                elseif($height>=136.5 && $height<=143.4){
                    return "Stunted";
                }
                elseif($height>=143.5 && $height<=171.3){
                    return "Normal";
                }
                elseif($height>=171.4){
                    return "Tall";
                }
            }

            if($year==13 && $months==4){
                if($height<=136.8){
                    return "Severely stunted";
                }
                elseif($height>=136.9 && $height<=143.7){
                    return "Stunted";
                }
                elseif($height>=143.8 && $height<=171.6){
                    return "Normal";
                }
                elseif($height>=171.7){
                    return "Tall";
                }
            }

            if($year==13 && $months==5){
                if($height<=137.1){
                    return "Severely stunted";
                }
                elseif($height>=137.2 && $height<=144.0){
                    return "Stunted";
                }
                elseif($height>=144.1 && $height<=171.9){
                    return "Normal";
                }
                elseif($height>=172.0){
                    return "Tall";
                }
            }

            if($year==13 && $months==6){
                if($height<=137.3){
                    return "Severely stunted";
                }
                elseif($height>=137.4 && $height<=144.3){
                    return "Stunted";
                }
                elseif($height>=144.4 && $height<=172.2){
                    return "Normal";
                }
                elseif($height>=172.3){
                    return "Tall";
                }
            }

            if($year==13 && $months==7){
                if($height<=137.6){
                    return "Severely stunted";
                }
                elseif($height>=137.7 && $height<=144.6){
                    return "Stunted";
                }
                elseif($height>=144.7 && $height<=172.5){
                    return "Normal";
                }
                elseif($height>=172.6){
                    return "Tall";
                }
            }

            if($year==13 && $months==8){
                if($height<=137.9){
                    return "Severely stunted";
                }
                elseif($height>=138.0 && $height<=144.8){
                    return "Stunted";
                }
                elseif($height>=144.9 && $height<=172.7){
                    return "Normal";
                }
                elseif($height>=172.8){
                    return "Tall";
                }
            }

            if($year==13 && $months==9){
                if($height<=138.1){
                    return "Severely stunted";
                }
                elseif($height>=138.2 && $height<=145.1){
                    return "Stunted";
                }
                elseif($height>=145.2 && $height<=173.0){
                    return "Normal";
                }
                elseif($height>=173.1){
                    return "Tall";
                }
            }

            if($year==13 && $months==10){
                if($height<=138.4){
                    return "Severely stunted";
                }
                elseif($height>=138.5 && $height<=145.3){
                    return "Stunted";
                }
                elseif($height>=145.4 && $height<=173.2){
                    return "Normal";
                }
                elseif($height>=173.3){
                    return "Tall";
                }
            }

            if($year==13 && $months==11){
                if($height<=138.6){
                    return "Severely stunted";
                }
                elseif($height>=138.7 && $height<=145.6){
                    return "Stunted";
                }
                elseif($height>=145.7 && $height<=173.5){
                    return "Normal";
                }
                elseif($height>=173.6){
                    return "Tall";
                }
            }

            if($year==14 && $months==0){
                if($height<=138.9){
                    return "Severely stunted";
                }
                elseif($height>=139.0 && $height<=145.8){
                    return "Stunted";
                }
                elseif($height>=145.9 && $height<=173.7){
                    return "Normal";
                }
                elseif($height>=173.8){
                    return "Tall";
                }
            }

            if($year==14 && $months==1){
                if($height<=139.1){
                    return "Severely stunted";
                }
                elseif($height>=139.2 && $height<=146.0){
                    return "Stunted";
                }
                elseif($height>=146.1 && $height<=173.9){
                    return "Normal";
                }
                elseif($height>=174.0){
                    return "Tall";
                }
            }

            if($year==14 && $months==2){
                if($height<=139.3){
                    return "Severely stunted";
                }
                elseif($height>=139.4 && $height<=146.2){
                    return "Stunted";
                }
                elseif($height>=146.3 && $height<=174.1){
                    return "Normal";
                }
                elseif($height>=174.2){
                    return "Tall";
                }
            }

            if($year==14 && $months==3){
                if($height<=139.5){
                    return "Severely stunted";
                }
                elseif($height>=139.6 && $height<=146.4){
                    return "Stunted";
                }
                elseif($height>=146.5 && $height<=174.2){
                    return "Normal";
                }
                elseif($height>=174.3){
                    return "Tall";
                }
            }


            if($year==14 && $months==4){
                if($height<=139.7){
                    return "Severely stunted";
                }
                elseif($height>=139.8 && $height<=146.6){
                    return "Stunted";
                }
                elseif($height>=146.7 && $height<=174.4){
                    return "Normal";
                }
                elseif($height>=174.5){
                    return "Tall";
                }
            }

            if($year==14 && $months==5){
                if($height<=139.9){
                    return "Severely stunted";
                }
                elseif($height>=140.0 && $height<=146.8){
                    return "Stunted";
                }
                elseif($height>=146.9 && $height<=174.6){
                    return "Normal";
                }
                elseif($height>=174.7){
                    return "Tall";
                }
            }

            if($year==14 && $months==6){
                if($height<=140.0){
                    return "Severely stunted";
                }
                elseif($height>=140.1 && $height<=147.0){
                    return "Stunted";
                }
                elseif($height>=147.1 && $height<=174.7){
                    return "Normal";
                }
                elseif($height>=174.8){
                    return "Tall";
                }
            }

            if($year==14 && $months==7){
                if($height<=140.2){
                    return "Severely stunted";
                }
                elseif($height>=140.3 && $height<=147.1){
                    return "Stunted";
                }
                elseif($height>=147.2 && $height<=174.9){
                    return "Normal";
                }
                elseif($height>=175.0){
                    return "Tall";
                }
            }

            if($year==14 && $months==8){
                if($height<=140.4){
                    return "Severely stunted";
                }
                elseif($height>=140.5 && $height<=147.3){
                    return "Stunted";
                }
                elseif($height>=147.4 && $height<=175.0){
                    return "Normal";
                }
                elseif($height>=175.1){
                    return "Tall";
                }
            }

            if($year==14 && $months==9){
                if($height<=140.5){
                    return "Severely stunted";
                }
                elseif($height>=140.6 && $height<=147.4){
                    return "Stunted";
                }
                elseif($height>=147.5 && $height<=175.1){
                    return "Normal";
                }
                elseif($height>=175.2){
                    return "Tall";
                }
            }

            if($year==14 && $months==10){
                if($height<=140.7){
                    return "Severely stunted";
                }
                elseif($height>=140.8 && $height<=147.6){
                    return "Stunted";
                }
                elseif($height>=147.7 && $height<=175.2){
                    return "Normal";
                }
                elseif($height>=175.3){
                    return "Tall";
                }
            }

            if($year==14 && $months==11){
                if($height<=140.8){
                    return "Severely stunted";
                }
                elseif($height>=140.9 && $height<=147.7){
                    return "Stunted";
                }
                elseif($height>=147.8 && $height<=175.3){
                    return "Normal";
                }
                elseif($height>=175.4){
                    return "Tall";
                }
            }

            if($year==15 && $months==0){
                if($height<=140.9){
                    return "Severely stunted";
                }
                elseif($height>=141.0 && $height<=147.8){
                    return "Stunted";
                }
                elseif($height>=147.9 && $height<=175.4){
                    return "Normal";
                }
                elseif($height>=175.5){
                    return "Tall";
                }
            }

            if($year==15 && $months==1){
                if($height<=141.1){
                    return "Severely stunted";
                }
                elseif($height>=141.2 && $height<=147.9){
                    return "Stunted";
                }
                elseif($height>=148.0 && $height<=175.5){
                    return "Normal";
                }
                elseif($height>=175.6){
                    return "Tall";
                }
            }

            if($year==15 && $months==2){
                if($height<=141.2){
                    return "Severely stunted";
                }
                elseif($height>=141.3 && $height<=148.0){
                    return "Stunted";
                }
                elseif($height>=148.1 && $height<=175.6){
                    return "Normal";
                }
                elseif($height>=175.7){
                    return "Tall";
                }
            }

            if($year==15 && $months==3){
                if($height<=141.3){
                    return "Severely stunted";
                }
                elseif($height>=141.4 && $height<=148.1){
                    return "Stunted";
                }
                elseif($height>=148.2 && $height<=175.7){
                    return "Normal";
                }
                elseif($height>=175.8){
                    return "Tall";
                }
            }

            if($year==15 && $months==4){
                if($height<=141.4){
                    return "Severely stunted";
                }
                elseif($height>=141.4 && $height<=148.2){
                    return "Stunted";
                }
                elseif($height>=148.3 && $height<=175.7){
                    return "Normal";
                }
                elseif($height>=175.8){
                    return "Tall";
                }
            }

            if($year==15 && $months==5){
                if($height<=141.5){
                    return "Severely stunted";
                }
                elseif($height>=141.6 && $height<=148.3){
                    return "Stunted";
                }
                elseif($height>=148.4 && $height<=175.8){
                    return "Normal";
                }
                elseif($height>=175.9){
                    return "Tall";
                }
            }

            if($year==15 && $months==6){
                if($height<=141.6){
                    return "Severely stunted";
                }
                elseif($height>=141.7 && $height<=148.4){
                    return "Stunted";
                }
                elseif($height>=148.5 && $height<=175.9){
                    return "Normal";
                }
                elseif($height>=176.0){
                    return "Tall";
                }
            }

            if($year==15 && $months==7){
                if($height<=141.7){
                    return "Severely stunted";
                }
                elseif($height>=141.8 && $height<=148.5){
                    return "Stunted";
                }
                elseif($height>=148.6 && $height<=175.9){
                    return "Normal";
                }
                elseif($height>=176.0){
                    return "Tall";
                }
            }

            if($year==15 && $months==8){
                if($height<=141.8){
                    return "Severely stunted";
                }
                elseif($height>=141.9 && $height<=148.6){
                    return "Stunted";
                }
                elseif($height>=148.7 && $height<=176.0){
                    return "Normal";
                }
                elseif($height>=176.1){
                    return "Tall";
                }
            }

            if($year==15 && $months==9){
                if($height<=141.8){
                    return "Severely stunted";
                }
                elseif($height>=141.9 && $height<=148.6){
                    return "Stunted";
                }
                elseif($height>=148.7 && $height<=176.0){
                    return "Normal";
                }
                elseif($height>=176.1){
                    return "Tall";
                }
            }

            if($year==15 && $months==10){
                if($height<=141.9){
                    return "Severely stunted";
                }
                elseif($height>=142.0 && $height<=148.7){
                    return "Stunted";
                }
                elseif($height>=148.8 && $height<=176.0){
                    return "Normal";
                }
                elseif($height>=176.1){
                    return "Tall";
                }
            }

            if($year==15 && $months==11){
                if($height<=142.0){
                    return "Severely stunted";
                }
                elseif($height>=142.1 && $height<=148.8){
                    return "Stunted";
                }
                elseif($height>=148.9 && $height<=176.1){
                    return "Normal";
                }
                elseif($height>=176.2){
                    return "Tall";
                }
            }

            if($year==16 && $months==0){
                if($height<=142.1){
                    return "Severely stunted";
                }
                elseif($height>=142.2 && $height<=148.8){
                    return "Stunted";
                }
                elseif($height>=148.9 && $height<=176.1){
                    return "Normal";
                }
                elseif($height>=176.2){
                    return "Tall";
                }
            }

            if($year==16 && $months==1){
                if($height<=142.1){
                    return "Severely stunted";
                }
                elseif($height>=142.2 && $height<=148.9){
                    return "Stunted";
                }
                elseif($height>=149.0 && $height<=176.1){
                    return "Normal";
                }
                elseif($height>=176.2){
                    return "Tall";
                }
            }

            if($year==16 && $months==2){
                if($height<=142.2){
                    return "Severely stunted";
                }
                elseif($height>=142.3 && $height<=149.0){
                    return "Stunted";
                }
                elseif($height>=149.1 && $height<=176.1){
                    return "Normal";
                }
                elseif($height>=176.2){
                    return "Tall";
                }
            }

            if($year==16 && $months==3){
                if($height<=142.2){
                    return "Severely stunted";
                }
                elseif($height>=142.3 && $height<=149.0){
                    return "Stunted";
                }
                elseif($height>=149.1 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year==16 && $months==4){
                if($height<=142.3){
                    return "Severely stunted";
                }
                elseif($height>=142.4 && $height<=149.1){
                    return "Stunted";
                }
                elseif($height>=149.2 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year==16 && $months==5){
                if($height<=142.3){
                    return "Severely stunted";
                }
                elseif($height>=142.4 && $height<=149.1){
                    return "Stunted";
                }
                elseif($height>=149.2 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year==16 && $months==6){
                if($height<=142.4){
                    return "Severely stunted";
                }
                elseif($height>=142.5 && $height<=149.1){
                    return "Stunted";
                }
                elseif($height>=149.2 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year==16 && $months==7){
                if($height<=142.4){
                    return "Severely stunted";
                }
                elseif($height>=142.5 && $height<=149.2){
                    return "Stunted";
                }
                elseif($height>=149.3 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year==16 && $months==8){
                if($height<=142.5){
                    return "Severely stunted";
                }
                elseif($height>=142.6 && $height<=149.2){
                    return "Stunted";
                }
                elseif($height>=149.3 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year==16 && $months==9){
                if($height<=142.5){
                    return "Severely stunted";
                }
                elseif($height>=142.6 && $height<=149.3){
                    return "Stunted";
                }
                elseif($height>=149.4 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year==16 && $months==10){
                if($height<=142.6){
                    return "Severely stunted";
                }
                elseif($height>=142.7 && $height<=149.3){
                    return "Stunted";
                }
                elseif($height>=149.4 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year==16 && $months==11){
                if($height<=142.6){
                    return "Severely stunted";
                }
                elseif($height>=142.7 && $height<=149.3){
                    return "Stunted";
                }
                elseif($height>=149.4 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year==17 && $months==0){
                if($height<=142.7){
                    return "Severely stunted";
                }
                elseif($height>=142.8 && $height<=149.4){
                    return "Stunted";
                }
                elseif($height>=149.5 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year==17 && $months==1){
                if($height<=142.7){
                    return "Severely stunted";
                }
                elseif($height>=142.8 && $height<=149.4){
                    return "Stunted";
                }
                elseif($height>=149.5 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year==17 && $months==2){
                if($height<=142.8){
                    return "Severely stunted";
                }
                elseif($height>=142.9 && $height<=149.4){
                    return "Stunted";
                }
                elseif($height>=149.5 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year==17 && $months==3){
                if($height<=142.8){
                    return "Severely stunted";
                }
                elseif($height>=142.9 && $height<=149.5){
                    return "Stunted";
                }
                elseif($height>=149.6 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==17 && $months==4){
                if($height<=142.8){
                    return "Severely stunted";
                }
                elseif($height>=142.9 && $height<=149.5){
                    return "Stunted";
                }
                elseif($height>=149.6 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==17 && $months==5){
                if($height<=142.9){
                    return "Severely stunted";
                }
                elseif($height>=143.0 && $height<=149.5){
                    return "Stunted";
                }
                elseif($height>=149.6 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==17 && $months==6){
                if($height<=142.9){
                    return "Severely stunted";
                }
                elseif($height>=143.0 && $height<=149.6){
                    return "Stunted";
                }
                elseif($height>=149.7 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==17 && $months==7){
                if($height<=143.0){
                    return "Severely stunted";
                }
                elseif($height>=143.1 && $height<=149.6){
                    return "Stunted";
                }
                elseif($height>=149.7 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==17 && $months==8){
                if($height<=143.0){
                    return "Severely stunted";
                }
                elseif($height>=143.1 && $height<=149.6){
                    return "Stunted";
                }
                elseif($height>=149.7 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==17 && $months==9){
                if($height<=143.0){
                    return "Severely stunted";
                }
                elseif($height>=143.1 && $height<=149.7){
                    return "Stunted";
                }
                elseif($height>=149.8 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==17 && $months==10){
                if($height<=143.1){
                    return "Severely stunted";
                }
                elseif($height>=143.2 && $height<=149.7){
                    return "Stunted";
                }
                elseif($height>=149.8 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==17 && $months==11){
                if($height<=143.1){
                    return "Severely stunted";
                }
                elseif($height>=143.2 && $height<=149.7){
                    return "Stunted";
                }
                elseif($height>=149.8 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==18 && $months==0){
                if($height<=143.1){
                    return "Severely stunted";
                }
                elseif($height>=143.2 && $height<=149.7){
                    return "Stunted";
                }
                elseif($height>=149.8 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==18 && $months==1){
                if($height<=143.2){
                    return "Severely stunted";
                }
                elseif($height>=143.3 && $height<=149.8){
                    return "Stunted";
                }
                elseif($height>=149.9 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==18 && $months==2){
                if($height<=143.2){
                    return "Severely stunted";
                }
                elseif($height>=143.3 && $height<=149.8){
                    return "Stunted";
                }
                elseif($height>=149.9 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==18 && $months==3){
                if($height<=143.2){
                    return "Severely stunted";
                }
                elseif($height>=143.3 && $height<=149.8){
                    return "Stunted";
                }
                elseif($height>=149.9 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==18 && $months==4){
                if($height<=143.3){
                    return "Severely stunted";
                }
                elseif($height>=143.4 && $height<=149.8){
                    return "Stunted";
                }
                elseif($height>=149.9 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==18 && $months==5){
                if($height<=143.3){
                    return "Severely stunted";
                }
                elseif($height>=143.4 && $height<=149.9){
                    return "Stunted";
                }
                elseif($height>=150.0 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==18 && $months==6){
                if($height<=143.3){
                    return "Severely stunted";
                }
                elseif($height>=143.4 && $height<=149.9){
                    return "Stunted";
                }
                elseif($height>=150.0 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==18 && $months==7){
                if($height<=143.3){
                    return "Severely stunted";
                }
                elseif($height>=143.4 && $height<=149.9){
                    return "Stunted";
                }
                elseif($height>=150.0 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==18 && $months==8){
                if($height<=143.4){
                    return "Severely stunted";
                }
                elseif($height>=143.5 && $height<=149.9){
                    return "Stunted";
                }
                elseif($height>=150.0 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==18 && $months==9){
                if($height<=143.4){
                    return "Severely stunted";
                }
                elseif($height>=143.5 && $height<=149.9){
                    return "Stunted";
                }
                elseif($height>=150.0 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==18 && $months==10){
                if($height<=143.4){
                    return "Severely stunted";
                }
                elseif($height>=143.5 && $height<=149.9){
                    return "Stunted";
                }
                elseif($height>=150.0 && $height<=176.3){
                    return "Normal";
                }
                elseif($height>=176.4){
                    return "Tall";
                }
            }

            if($year==18 && $months==11){
                if($height<=143.4){
                    return "Severely stunted";
                }
                elseif($height>=143.5 && $height<=150.0){
                    return "Stunted";
                }
                elseif($height>=150.1 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }

            if($year>=19){
                if($height<=143.4){
                    return "Severely stunted";
                }
                elseif($height>=143.5 && $height<=150.0){
                    return "Stunted";
                }
                elseif($height>=150.1 && $height<=176.2){
                    return "Normal";
                }
                elseif($height>=176.3){
                    return "Tall";
                }
            }






             
    }
}