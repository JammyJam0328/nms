<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ManageParents extends Component
{
    public function render()
    {
        return view('livewire.manage-parents');
    }
}
