<?php

namespace App\Http\Livewire\Adviser;

use Livewire\Component;

class ManageStudents extends Component
{
    public function render()
    {
        return view('livewire.adviser.manage-students');
    }
}
