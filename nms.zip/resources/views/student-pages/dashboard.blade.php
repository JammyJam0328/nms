@extends('layouts.student')
@section('body')
    <livewire:student-dashboard />
@endsection