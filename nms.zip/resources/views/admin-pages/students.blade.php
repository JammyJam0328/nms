@extends('layouts.admin')
@section('header')
    Manage Students
@endsection
@section('content')
    <div>
        <livewire:admin.manage-students />
    </div>
@endsection
