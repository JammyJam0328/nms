@extends('layouts.admin')
@section('header')
    Meal Plans
@endsection
@section('content')
    <div>
        <livewire:admin.meal-plan />
    </div>
@endsection
