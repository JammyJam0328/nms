@extends('layouts.admin')
@section('header')
        REPORTS
@endsection
@section('content')
    <div>
        <livewire:report />
    </div>
@endsection
