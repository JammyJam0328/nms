@extends('layouts.adviser')
@section('header')
    Monitor Students
@endsection
@section('content')
    <div>
        {{-- <livewire:adviser.manage-students.student-section
            :section_id="$id"
        /> --}}
        monitor students
    </div>
@endsection
